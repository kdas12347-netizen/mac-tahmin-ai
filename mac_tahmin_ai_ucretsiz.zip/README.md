# MaçTahmin AI — tamamen ücretsiz statik sürüm

Bu sürüm API anahtarı istemez ve dış servislere otomatik bağlanmaz. `index.html` tek başına çalışır; Safari'de açılabilir veya ücretsiz GitHub Pages ile yayımlanabilir.

## iPhone'da en kolay ücretsiz yayımlama
1. ZIP'i aç.
2. GitHub hesabı oluştur/giriş yap: https://github.com
3. New repository ile `mac-tahmin-ai` adlı herkese açık depo oluştur.
4. `index.html` dosyasını depoya yükle (Add file > Upload files > Commit changes).
5. Depoda Settings > Pages > Deploy from a branch > `main` ve `/ (root)` seç > Save.
6. GitHub'ın verdiği `https://KULLANICI.github.io/mac-tahmin-ai/` adresini Safari'de aç.

GitHub arayüzü değişebilir. Bu sürüm statik olduğu için API anahtarı, sunucu veya ücretli servis gerekmez.

## Kullanım
- Ev sahibi ve deplasman adlarını yaz.
- Gol beklentilerini girip hesapla.
- Geçmiş sonuç CSV'si yükleyip basit walk-forward MS testini çalıştır.
- Örnek CSV düğmesi biçim örneği indirir.

## Sınırlar
- Fikstür ve oranları otomatik çekmez; maç bilgileri ve gol beklentileri manuel girilir.
- İlk yarı oranları yaklaşık bir varsayımla hesaplanır.
- CSV testi basittir; gerçek performans için büyük, temiz ve tarihsel veri gerekir.
- Tahminler kesin değildir, kazanç garantisi yoktur.
